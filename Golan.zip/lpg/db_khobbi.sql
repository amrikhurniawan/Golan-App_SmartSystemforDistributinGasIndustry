-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2020 at 02:08 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_khobbi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_guruakting`
--

CREATE TABLE `tb_guruakting` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_guruakting`
--

INSERT INTO `tb_guruakting` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Naila', 'Akting', 'Bandung', 'perempuan', 'nailaaaa@gmail.com', '085237890055', 'pemain musical drama', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurubasket`
--

CREATE TABLE `tb_gurubasket` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurubasket`
--

INSERT INTO `tb_gurubasket` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Tika', 'basket', 'Makassar', 'perempuan', 'tika278@gmail.com', '081398342311', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurubultang`
--

CREATE TABLE `tb_gurubultang` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurubultang`
--

INSERT INTO `tb_gurubultang` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Kirana', 'bulu tangkis', 'Lampung', 'perempuan', 'kirana12@gmail.com', '081376539856', 'Pelatih bulu tangkis dan guru olahraga', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurudrum`
--

CREATE TABLE `tb_gurudrum` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurudrum`
--

INSERT INTO `tb_gurudrum` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Banji', 'Bermain alat musik drum', 'Bandung', 'Laki-Laki', 'banjihouse@gmail.com', '085345907633', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurugambar`
--

CREATE TABLE `tb_gurugambar` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(700) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurugambar`
--

INSERT INTO `tb_gurugambar` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Anasya', 'Menggambar dan Melukis', 'Sulawesi Selatan', 'Perempuan', 'anasyamus@gmail.com', '082346978421', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurugitar`
--

CREATE TABLE `tb_gurugitar` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurugitar`
--

INSERT INTO `tb_gurugitar` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Suci', 'Bermain alat musik gitar', 'Jakarta', 'perempuan', 'suci_aa@gmail.com', '085312096744', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurujahit`
--

CREATE TABLE `tb_gurujahit` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurujahit`
--

INSERT INTO `tb_gurujahit` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Novi', 'Menjahit', 'Bandung', 'Perempuan', 'santianovi@gmail.com', '085209674328', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurunyanyi`
--

CREATE TABLE `tb_gurunyanyi` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurunyanyi`
--

INSERT INTO `tb_gurunyanyi` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Devi', 'Bernyanyi', 'Kabupaten Bandung', 'Perempuan', 'deviianugrah@gmail.com', '085378315488', 'menjadi pelatih vokal', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_gurusepakbola`
--

CREATE TABLE `tb_gurusepakbola` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_gurusepakbola`
--

INSERT INTO `tb_gurusepakbola` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Dinar', 'Bermain Sepak Bola', 'Bandung', 'Laki-Laki', 'dinar123@gmail.com', '081367985677', 'Suka bermain sepak bola sejak sekolah dan menjadi pelatih ', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_guruvoli`
--

CREATE TABLE `tb_guruvoli` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_guruvoli`
--

INSERT INTO `tb_guruvoli` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Budi', 'Bermain Bola Voli', 'Jawa Barat Bandung', 'Laki-Laki', 'Budi24@gmail.com', '08135488618', 'Sebagai guru olahraga di SMP', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tb_loginguru`
--

CREATE TABLE `tb_loginguru` (
  `no` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_loginguru`
--

INSERT INTO `tb_loginguru` (`no`, `username`, `password`) VALUES
(1, 'sri', '1234567890'),
(2, 'ss', '0'),
(3, 'dfg', '0'),
(4, 'sridewi', '0'),
(5, 'sridewi', '1234567899'),
(6, 'x', '0'),
(7, 'sri', '2147483647'),
(8, 'bca', '0'),
(9, 'dewi', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tb_loginsiswa`
--

CREATE TABLE `tb_loginsiswa` (
  `no` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jk` varchar(25) NOT NULL,
  `hobi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_loginsiswa`
--

INSERT INTO `tb_loginsiswa` (`no`, `username`, `password`, `nama`, `jk`, `hobi`) VALUES
(1, 'sri', '1234567890', 'tika', 'perempuan', 'Bermain Alat Musik Gitar');

-- --------------------------------------------------------

--
-- Table structure for table `tb_piano`
--

CREATE TABLE `tb_piano` (
  `no` int(100) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `keahlian` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `jk` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nohp` varchar(50) NOT NULL,
  `deskripsi` varchar(700) NOT NULL,
  `prestasi` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_piano`
--

INSERT INTO `tb_piano` (`no`, `nama`, `keahlian`, `alamat`, `jk`, `email`, `nohp`, `deskripsi`, `prestasi`) VALUES
(1, 'Luna', 'Memainkan alat musik piano', 'Makassar', 'Perempuan', 'luna@gmail.com', '085398419566', 'Bermain Piano Selama 5 Tahun', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_guruakting`
--
ALTER TABLE `tb_guruakting`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurubasket`
--
ALTER TABLE `tb_gurubasket`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurubultang`
--
ALTER TABLE `tb_gurubultang`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurudrum`
--
ALTER TABLE `tb_gurudrum`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurugambar`
--
ALTER TABLE `tb_gurugambar`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurugitar`
--
ALTER TABLE `tb_gurugitar`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurujahit`
--
ALTER TABLE `tb_gurujahit`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurunyanyi`
--
ALTER TABLE `tb_gurunyanyi`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_gurusepakbola`
--
ALTER TABLE `tb_gurusepakbola`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_guruvoli`
--
ALTER TABLE `tb_guruvoli`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_loginguru`
--
ALTER TABLE `tb_loginguru`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_loginsiswa`
--
ALTER TABLE `tb_loginsiswa`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_piano`
--
ALTER TABLE `tb_piano`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_guruakting`
--
ALTER TABLE `tb_guruakting`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_gurubasket`
--
ALTER TABLE `tb_gurubasket`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_gurubultang`
--
ALTER TABLE `tb_gurubultang`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_gurudrum`
--
ALTER TABLE `tb_gurudrum`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_gurugambar`
--
ALTER TABLE `tb_gurugambar`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_gurugitar`
--
ALTER TABLE `tb_gurugitar`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_gurujahit`
--
ALTER TABLE `tb_gurujahit`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_gurunyanyi`
--
ALTER TABLE `tb_gurunyanyi`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_gurusepakbola`
--
ALTER TABLE `tb_gurusepakbola`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_guruvoli`
--
ALTER TABLE `tb_guruvoli`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tb_loginguru`
--
ALTER TABLE `tb_loginguru`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tb_loginsiswa`
--
ALTER TABLE `tb_loginsiswa`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_piano`
--
ALTER TABLE `tb_piano`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
