<?php
include 'koneksi.php';



if (@$_POST['daftarsiswa']) {
  $username = @$_POST['username'];
  $password = @$_POST['password'];
  $nama_mitra= @$_POST['nama_mitra'];
  $notlp =@$_POST['notlp'];
  $alamat = @$_POST['alamat'];
   $harga= @$_POST['harga'];
  $barang =@$_POST['barang'];
  



  mysqli_query($connect, "INSERT INTO tb_mitra VALUES ('','$username', '$password', '$nama_mitra', '$notlp', '$alamat', '$harga', '$barang')");

?>

<script type="text/javascript">
  alert("Registrasi berhasil");
  window.location.href="index.php";

</script>

<?php  }
?>

