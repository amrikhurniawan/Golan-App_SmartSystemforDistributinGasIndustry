<?php
error_reporting(0);
include 'koneksi.php';



if (@$_POST['daftarguru']) {
  $username = @$_POST['username'];
  $password = @$_POST['password'];




  mysqli_query($connect, "INSERT INTO tb_loginguru VALUES ('','$username', '$password')");

?>

<script type="text/javascript">
  alert("Registrasi berhasil");
  window.location.href="index.php";

</script>

<?php  }
?>

