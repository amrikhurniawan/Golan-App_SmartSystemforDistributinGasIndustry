<?php
error_reporting(0);
include 'koneksi.php';



if (@$_POST['sewa']) {
  $nama = @$_POST['nama'];
  $alamat = @$_POST['alamat'];
  $notlp= @$_POST['notlp'];
  $waktusewa= @$_POST['waktusewa'];




  mysqli_query($connect, "INSERT INTO tb_sewa VALUES ('','$nama', '$alamat', '$notlp', '$waktusewa')");

?>

<script type="text/javascript">
  alert("Pengisian Form Pembelian Berhasil");
  window.location.href="halamanbayar.php";

<?php  }
?>

