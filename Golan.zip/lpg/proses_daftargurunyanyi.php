<?php
error_reporting(0);
include 'koneksi.php';



if (@$_POST['daftargurunyanyi']) {
  $nama = @$_POST['nama'];
  $keahlian = @$_POST['keahlian'];
  $alamat= @$_POST['alamat'];
  $jk =@$_POST['jk'];
  $email = @$_POST['email'];
  $nohp = @$_POST['nohp'];
  $deskripsi = @$_POST['deskripsi'];
  $prestasi = @$_POST['prestasi'];
  $harga = @$_POST['harga'];
  $metodologi = @$_POST['metodologi'];
  $kelas_diadakan = @$_POST['kelas_diadakan'];



  mysqli_query($connect, "INSERT INTO tb_gurunyanyi VALUES ('','$nama', '$keahlian', '$alamat', '$jk', '$email','$nohp', '$deskripsi', '$prestasi', '$harga', '$metodologi', '$kelas_diadakan')");

?>

<script type="text/javascript">
  alert("Daftar Berhasil");
  window.location.href="setelahgurulogin_listsiswa.php";

</script>

<?php  }
?>

