const loginForm = document.querySelector('#login-form');
loginForm.addEventListener('submit', (e) => {
	e.preventDefault();

	var email = loginForm['login-email'].value;
	var password = loginForm['login-password'].value;
	if (email =="admin123@gmail.com" && password == 'admin123'){
		
		alert("Website Sedang Dalam Proses Perkembangan");
		window.location.href = "index.html";
	}
	else {
		document.getElementById("alert").innerText = 'Username or Password Incorrect'; 
	}

		const modal = document.querySelector('#modal-login');
		M.Modal.getInstance(modal).close();
		loginForm.reset();
	}); 

