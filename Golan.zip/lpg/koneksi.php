<?php

$host  = 'localhost';
$user  = 'root';
$pass  = '';
$db    = 'db_khobbi';
$connect = new mysqli($host, $user, $pass, $db);
if($connect->connect_error){
 echo 'Terjadi Kesalahan';
}

?>