<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Golan</title>
  <link rel="icon" href="img/fav-icon.png" type="image/x-icon" />
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="style_login.css">
</head>

<body>
   <script src="https://www.gstatic.com/firebasejs/6.3.1/firebase-app.js"></script>
 <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
 <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  
<div class="container">
  <div class="info">
    <h1> Daftar </h1> 
  </div>
</div>
<div class="form">
  <div id="modal-signup" class="modal">
  <div class="thumbnail"><img src="png.png"/></div>
  <form class="login-form" method="post">
    <div class="input-field">
    <input type="text" name="username" required placeholder="Username"/>
     <input type="password" name="password" required placeholder="Password"/>
    
    <button type="submit" name="daftarguru" value="Daftarguru">Buat Akun</button>

    <p class="message">Sudah Punya Akun?<a href="login_siswa.php">Masuk</a></p>
    <p class="message">Kembali ke <a href="index.php">Halaman Utama</a></p>
  </form>
</div>
</div>
</div>
</body>
</html>

<?php
include 'proses_daftarguru.php';
?>
