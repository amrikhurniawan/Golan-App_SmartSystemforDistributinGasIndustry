<?php
include 'koneksi.php';

$username = @$_POST['username'];
$password = @$_POST['password'];

$query    = "SELECT * FROM tb_loginguru WHERE username = '$username' AND password = '$password'";
$runquery = $connect->query($query);

if($runquery->num_rows>0){
 session_start();
 $_SESSION['username'] = $username;
  $_SESSION['password'] = $password;
 header("location:setelahlogin_siswa.php");
} 
else
 {
 echo "<h1></h1>";
}

?>
