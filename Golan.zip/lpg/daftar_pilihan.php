<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Khobbi</title>
  <link rel="icon" href="img/fav-icon.png" type="image/x-icon" />
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
<link rel="icon" type="image/png" href="sampah.png">
      <link rel="stylesheet" href="style_login.css">
</head>

<body>
   <script src="https://www.gstatic.com/firebasejs/6.3.1/firebase-app.js"></script>
 <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-auth.js"></script>
 <script src="https://www.gstatic.com/firebasejs/5.10.1/firebase-database.js"></script>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  
<div class="container">
  <div class="info">
    <h1> Daftar Sebagai ..... </h1> 
  </div>
</div>

<div class="formmurid">

  <a class="navbar-brand" href="Daftar_siswa.php?page=daftarsiswa" name="daftarsiswa"><img src="murid.png"></a>
</div>

<div class="formguru">

  <a class="navbar-brand" href="Daftar_guru.php?page=daftarguru" name="daftarguru"><img src="guru.png"></a>
</div>

</body>
</html>


