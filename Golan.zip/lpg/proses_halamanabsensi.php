<?php
include 'koneksi.php';

error_reporting(0);

if (@$_POST['absensi']) {
  $nama = @$_POST['nama'];
  $tgl = @$_POST['tgl'];
  $deskripsi= @$_POST['deskripsi'];




  mysqli_query($connect, "INSERT INTO tb_absensi VALUES ('','$tgl', '$nama', '$deskripsi')");

?>

<script type="text/javascript">
  alert("Absensi Siswa Telah Anda Masukkan");
  window.location.href="halaman_absensiguru.php";

</script>

<?php  }
?>

