<?php
error_reporting(0);
include 'koneksi.php';



if (@$_POST['daftargurugambar']) {
  $nama = @$_POST['nama'];
  $keahlian = @$_POST['keahlian'];
  $alamat= @$_POST['alamat'];
  $jk =@$_POST['jk'];
  $email = @$_POST['email'];
  $nohp = @$_POST['nohp'];
  $deskripsi = @$_POST['deskripsi'];
  $prestasi = @$_POST['prestasi'];



  mysqli_query($connect, "INSERT INTO tb_gurugambar VALUES ('','$nama', '$keahlian', '$alamat', '$jk', '$email','$nohp', '$deskripsi', '$prestasi')");

?>

<script type="text/javascript">
  alert("Daftar Berhasil");
  window.location.href="setelahgurulogin_listsiswa.php";

</script>

<?php  }
?>

