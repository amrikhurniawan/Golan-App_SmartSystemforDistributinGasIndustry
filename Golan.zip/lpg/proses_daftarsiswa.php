<?php
include 'koneksi.php';



if (@$_POST['daftarsiswa']) {
  $username = @$_POST['username'];
  $password = @$_POST['password'];
  $nama= @$_POST['nama'];
  $jk =@$_POST['jk'];
  $hobi = @$_POST['hobi'];



  mysqli_query($connect, "INSERT INTO tb_loginsiswa VALUES ('','$username', '$password', '$nama', '$jk', '$hobi')");

?>

<script type="text/javascript">
  alert("Registrasi berhasil");
  window.location.href="index.php";

</script>

<?php  }
?>

